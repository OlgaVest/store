# shop/models.py

from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator

class Category(models.Model):
    """Категория товаров с возможностью вложенности."""
    name = models.CharField(max_length=100, verbose_name="Название категории")
    description = models.TextField(blank=True, verbose_name="Описание категории")
    parent = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name='subcategories',
        verbose_name="Родительская категория"
    )

    def __str__(self):
        return f"{self.parent.name} → {self.name}" if self.parent else self.name

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"
        ordering = ['name']


class Product(models.Model):
    """Товар интернет-магазина."""
    name = models.CharField(max_length=200, verbose_name="Название товара")
    description = models.TextField(blank=True, verbose_name="Описание товара")
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0.01)],
        verbose_name="Цена"
    )
    stock = models.PositiveIntegerField(default=0, verbose_name="Количество на складе")
    image = models.ImageField(upload_to='products/', blank=True, null=True, verbose_name="Изображение товара")
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        related_name='products',
        verbose_name="Категория"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата добавления")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Товар"
        verbose_name_plural = "Товары"
        ordering = ['-created_at']
        unique_together = ('name', 'category')
        db_table = 'shop_products'


class Order(models.Model):
    """
    Модель для представления заказа пользователя.
    """
    # 1. Определяем варианты для поля статуса
    STATUS_CHOICES = [
        ('pending', 'В обработке'),
        ('shipped', 'Доставляется'),
        ('delivered', 'Доставлено'),
        ('cancelled', 'Отменено'),
    ]

    # 2. Поля модели
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='orders',
        verbose_name="Пользователь"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Дата создания заказа"
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending',
        verbose_name="Статус заказа"
    )
    # Поле для хранения общей стоимости
    total_price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0.00,
        verbose_name="Общая стоимость заказа"
    )

    # 3. Методы
    def __str__(self):
        """Возвращает строковое представление заказа."""
        return f"Заказ #{self.id} от {self.user.username}"

    def get_total_price(self):
        """
        Рассчитывает и возвращает общую стоимость заказа,
        суммируя стоимость всех товаров (количество * цена товара).
        """
        total = sum(item.get_cost() for item in self.items.all())
        # Примечание: Это значение рассчитывается динамически.
        # Если вы хотите сохранить его в поле total_price, раскомментируйте строки ниже:
        # self.total_price = total
        # self.save(update_fields=['total_price'])
        return total


class OrderItem(models.Model):
    """Позиция заказа — товар + количество."""
    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name='items',
        verbose_name="Заказ"
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='order_items',
        verbose_name="Товар"
    )
    quantity = models.PositiveIntegerField(
        default=1,
        validators=[MinValueValidator(1)],
        verbose_name="Количество"
    )

    def __str__(self):
        return f"{self.quantity} × {self.product.name}"

    def get_cost(self):
        return self.quantity * self.product.price

    class Meta:
        verbose_name = "Элемент заказа"
        verbose_name_plural = "Элементы заказа"


class Review(models.Model):
    """Отзывы на товары от пользователей."""
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='reviews',
        verbose_name="Товар"
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='reviews',
        verbose_name="Пользователь"
    )
    rating = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name="Оценка (1–5)"
    )
    comment = models.TextField(blank=True, verbose_name="Текст отзыва")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")

    def __str__(self):
        return f"Отзыв от {self.user.username} на {self.product.name} (Оценка: {self.rating})"

    class Meta:
        verbose_name = "Отзыв"
        verbose_name_plural = "Отзывы"
        ordering = ['-created_at']
        unique_together = ('product', 'user')

# shop/models.py (добавить в конец файла)

class Cart(models.Model):
    """
    Модель для представления корзины покупок пользователя.
    """
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='cart',
        verbose_name="Пользователь"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Дата последнего изменения")

    def __str__(self):
        return f"Корзина пользователя {self.user.username}"

    def get_total_items(self):
        """Возвращает общее количество товаров в корзине."""
        return sum(item.quantity for item in self.items.all())

    def get_total_price(self):
        """Возвращает общую стоимость товаров в корзине."""
        return sum(item.get_cost() for item in self.items.all())

    class Meta:
        verbose_name = "Корзина"
        verbose_name_plural = "Корзины"
        ordering = ['-created_at']


# shop/models.py (добавить сразу после класса Cart)

class CartItem(models.Model):
    """
    Модель для представления одного товара в корзине.
    """
    cart = models.ForeignKey(
        Cart,
        on_delete=models.CASCADE,
        related_name='items',
        verbose_name="Корзина"
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='cart_items',
        verbose_name="Товар"
    )
    quantity = models.PositiveIntegerField(
        default=1,
        validators=[MinValueValidator(1)],
        verbose_name="Количество"
    )

    def __str__(self):
        return f"{self.quantity} x {self.product.name}"

    def get_cost(self):
        """Возвращает стоимость этого элемента корзины (количество * цена товара)."""
        return self.quantity * self.product.price

    class Meta:
        verbose_name = "Элемент корзины"
        verbose_name_plural = "Элементы корзины"
        # Один и тот же товар не должен добавляться в корзину дважды.
        # Если пользователь добавляет товар снова, увеличивается его количество.
        unique_together = ('cart', 'product')
