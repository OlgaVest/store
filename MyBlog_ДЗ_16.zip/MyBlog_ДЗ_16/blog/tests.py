# Create your tests here.
# blog/tests.py

from django.test import TestCase
from django.urls import reverse
from .models import Post

class BlogTests(TestCase):

    def setUp(self):
        """Создаём тестовый пост перед каждым тестом"""
        self.post = Post.objects.create(
            title='Тестовый заголовок',
            content='Тестовое содержание поста.'
        )

    def test_home_page_status_code(self):
        """Проверка доступности главной страницы"""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)

    def test_about_page_status_code(self):
        """Проверка доступности страницы 'О нас'"""
        response = self.client.get('/about/')
        self.assertEqual(response.status_code, 200)

    def test_post_list_page_status_code(self):
        """Проверка доступности списка постов"""
        response = self.client.get('/posts/')
        self.assertEqual(response.status_code, 200)

    def test_post_detail_page_status_code(self):
        """Проверка доступности страницы конкретного поста"""
        response = self.client.get(f'/posts/{self.post.pk}/')
        self.assertEqual(response.status_code, 200)

    def test_post_create_page_status_code(self):
        """Проверка доступности страницы создания поста"""
        response = self.client.get('/posts/create/')
        self.assertEqual(response.status_code, 200)

    def test_post_content_in_list(self):
        """Проверка, что пост отображается в списке"""
        response = self.client.get('/posts/')
        self.assertContains(response, 'Тестовый заголовок')

    def test_post_content_in_detail(self):
        """Проверка, что содержание поста отображается на странице деталей"""
        response = self.client.get(f'/posts/{self.post.pk}/')
        self.assertContains(response, 'Тестовое содержание поста.')