from django.urls import path
from . import views

urlpatterns = [
    path('', views.post_list, name='post_list'),
]

#from django.contrib import admin
#from django.urls import path, include  # добавили include для подключения приложения

#urlpatterns = [
#    path('admin/', admin.site.urls),
#    path('', include('blog.urls')),  # подключаем маршруты приложения blog
#]