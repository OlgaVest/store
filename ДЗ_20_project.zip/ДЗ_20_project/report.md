# Отчет по Домашнему Заданию: Модели и Запросы ORM

## 1. Код новой модели `Genre` и изменённой модели `Book`

### Модель `Genre` (из `books/models.py`)

```python
class Genre(models.Model):
    """
    Модель для представления жанра книги.
    """
    name = models.CharField(max_length=100, verbose_name="Название жанра")
    description = models.TextField(blank=True, verbose_name="Описание жанра")

    def __str__(self):
        """
        Возвращает строковое представление жанра.
        """
        return self.name

    class Meta:
        verbose_name = "Жанр"
        verbose_name_plural = "Жанры"
        ordering = ['name'] # Сортировка по имени по умолчанию

2. Список жанров, добавленных через админку

Фантастика
Детектив
Роман
3. Ответы на запросы в Django Shell        

![books.png](../../../Lightshot/books.png)