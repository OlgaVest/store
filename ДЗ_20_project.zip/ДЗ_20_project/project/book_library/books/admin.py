# books/admin.py

from django.contrib import admin
from .models import Author, Book, Genre # <-- Добавлен импорт Genre


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author')
    search_fields = ('title', 'author__name')

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('name', 'bio')
    search_fields = ('name', 'bio')

# =================== ДОБАВЛЕНО ===================
@admin.register(Genre) # <-- Регистрация модели Genre
class GenreAdmin(admin.ModelAdmin):
    """
    Настройка отображения модели Genre в админке.
    """
    list_display = ('name', 'description') # Поля, отображаемые в списке
    search_fields = ('name', 'description') # Поля, по которым можно искать
    # Можно добавить фильтры, сортировку и т.д.
# ================================================

