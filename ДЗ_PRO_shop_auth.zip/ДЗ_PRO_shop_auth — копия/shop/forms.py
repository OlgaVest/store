# shop/forms.py

from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser


class CustomUserCreationForm(UserCreationForm):
    """
    Кастомная форма регистрации пользователя.
    Использует кастомную модель CustomUser.
    """
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'placeholder': 'your@email.com'}),
        label="Электронная почта"
    )
    phone_number = forms.CharField(
        max_length=20,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': '+7 (XXX) XXX-XX-XX'}),
        label="Номер телефона (необязательно)"
    )
    address = forms.CharField(
        max_length=255,
        required=False,
        widget=forms.TextInput(attrs={'placeholder': 'Ваш адрес для доставки'}),
        label="Адрес доставки (необязательно)"
    )

    class Meta:
        model = CustomUser
        fields = ("email", "phone_number", "address", "password1", "password2")

    def save(self, commit=True):
        """
        Сохраняет пользователя. Устанавливает is_active в False до подтверждения email.
        """
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.phone_number = self.cleaned_data.get('phone_number', '')
        user.address = self.cleaned_data.get('address', '')
        # is_active по умолчанию False в модели, но явно укажем для ясности
        user.is_active = False
        if commit:
            user.save()
        return user


class CustomAuthenticationForm(AuthenticationForm):
    """
    Кастомная форма аутентификации.
    Использует email вместо username.
    """
    username = forms.EmailField(
        widget=forms.EmailInput(attrs={'autofocus': True, 'placeholder': 'your@email.com'}),
        label="Электронная почта"
    )

    class Meta:
        model = CustomUser
        fields = ('username', 'password')
