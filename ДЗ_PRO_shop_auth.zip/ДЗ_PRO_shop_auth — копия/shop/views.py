# shop/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.mail import send_mail
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.conf import settings
from .forms import CustomUserCreationForm, CustomAuthenticationForm
from .models import CustomUser


def register(request):
    """
    Представление для страницы регистрации.
    """
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            # is_active по умолчанию False в модели и в форме, но явно укажем
            user.is_active = False
            user.save()

            # --- Отправка email с подтверждением ---
            # Получаем текущий сайт (для формирования ссылки)
            current_site = get_current_site(request)
            site_name = current_site.name
            domain = current_site.domain

            # Генерация токена для подтверждения email
            token = default_token_generator.make_token(user)
            uid = urlsafe_base64_encode(force_bytes(user.pk))

            # Формируем ссылку для активации
            # Примечание: Убедитесь, что маршрут 'activate' существует в urls.py
            activation_link = f"http://{domain}/activate/{uid}/{token}/"

            # Рендерим тело письма из шаблона (создадим позже)
            subject = f'Активируйте ваш аккаунт на {site_name}'
            message = render_to_string('shop/activation_email.html', {
                'user': user,
                'domain': domain,
                'uid': uid,
                'token': token,
                'activation_link': activation_link,
            })

            # Отправляем email
            try:
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL, # Используем email из settings.py
                    [user.email],
                    fail_silently=False,
                )
                messages.success(request, 'Регистрация прошла успешно! Проверьте вашу почту для подтверждения аккаунта.')
            except Exception as e:
                # Лучше логировать ошибку
                messages.error(request, f'Ошибка при отправке письма: {e}. Пожалуйста, свяжитесь с администратором.')
                # Можно удалить пользователя, если письмо не ушло?
                # user.delete()

            return redirect('email_confirmation_sent') # Перенаправляем на страницу "письмо отправлено"
        # Если форма не валидна, она автоматически отрендерится с ошибками
    else:
        form = CustomUserCreationForm()
    return render(request, 'shop/register.html', {'form': form})


def activate(request, uidb64, token):
    """
    Представление для активации аккаунта по ссылке из email.
    """
    try:
        # Декодируем UID
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = CustomUser.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, CustomUser.DoesNotExist):
        user = None

    # Проверяем токен и активируем пользователя
    if user is not None and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        messages.success(request, 'Ваш аккаунт успешно активирован! Теперь вы можете войти.')
        return redirect('login')
    else:
        messages.error(request, 'Ссылка для активации недействительна или срок её действия истёк.')
        return redirect('register') # Или на главную


def login_view(request):
    """
    Представление для страницы входа.
    """
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('username') # Помним, что поле переопределено на email
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)
            if user:
                if user.is_active: # Проверяем, активен ли аккаунт
                    login(request, user)
                    messages.success(request, f"Вы вошли в систему как {email}.")
                    # Перенаправление (можно на профиль или главную)
                    next_page = request.GET.get('next')
                    return redirect(next_page or 'profile')
                else:
                    messages.error(request, "Ваш аккаунт не активирован. Проверьте вашу почту.")
            else:
                messages.error(request, "Неверный email или пароль.")
        # Если форма не валидна, она автоматически отрендерится с ошибками
    else:
        form = CustomAuthenticationForm()
    return render(request, 'shop/login.html', {'form': form})


def logout_view(request):
    """
    Представление для выхода из системы.
    """
    logout(request)
    messages.info(request, "Вы вышли из системы.")
    return redirect('login') # Или на главную


@login_required
def profile_view(request):
    """
    Представление для личного кабинета пользователя.
    Доступно только авторизованным пользователям.
    """
    user = request.user
    if request.method == 'POST':
        # Здесь можно добавить логику для редактирования профиля
        # Например, обновление phone_number и address
        # Пока просто покажем сообщение
        messages.info(request, "Редактирование профиля пока не реализовано.")
        return redirect('profile')
    else:
        context = {
            'user': user,
        }
        return render(request, 'shop/profile.html', context)

# --- Вспомогательные представления ---

def email_confirmation_sent(request):
    """
    Страница, уведомляющая, что письмо с подтверждением отправлено.
    """
    return render(request, 'shop/email_confirmation_sent.html')

# def forgot_password(request):
#     """
#     (Бонус) Представление для восстановления пароля.
#     """
#     # Реализация будет позже
#     pass

# def delete_account(request):
#     """
#     (Бонус) Представление для удаления аккаунта.
#     """
#     # Реализация будет позже
#     pass
from django.shortcuts import render

# Create your views here.
