# shop/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('activate/<uidb64>/<token>/', views.activate, name='activate'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile_view, name='profile'),
    path('email-confirmation-sent/', views.email_confirmation_sent, name='email_confirmation_sent'),
    # path('forgot-password/', views.forgot_password, name='forgot_password'), # Будет позже
    # path('delete-account/', views.delete_account, name='delete_account'), # Будет позже
    # path('', views.home, name='home'), # Главная страница, если будет
]