# shop/models.py

from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager


class CustomUserManager(BaseUserManager):
    """
    Кастомный менеджер для модели CustomUser.
    Определяет, как создаются пользователи и суперпользователи.
    """

    def create_user(self, email, password=None, **extra_fields):
        """
        Создает и возвращает пользователя с email и паролем.
        """
        if not email:
            raise ValueError('У пользователя должен быть адрес электронной почты')

        email = self.normalize_email(email)  # Приводит email к нижнему регистру
        # Создаем экземпляр модели CustomUser (или той, что указана в self.model)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)  # Хэширует пароль
        user.save(using=self._db)  # Используем базу данных менеджера
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        """
        Создает и возвращает суперпользователя.
        """
        # Устанавливаем значения по умолчанию для суперпользователя
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_active', True)
        extra_fields.setdefault('is_superuser', True)

        # Проверки для безопасности
        if extra_fields.get('is_staff') is not True:
            raise ValueError('Суперпользователь должен иметь is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Суперпользователь должен иметь is_superuser=True.')

        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractBaseUser, PermissionsMixin):
    """
    Кастомная модель пользователя, использующая email вместо username.
    """
    email = models.EmailField(unique=True, verbose_name="Электронная почта")
    phone_number = models.CharField(max_length=20, blank=True, verbose_name="Номер телефона")
    address = models.CharField(max_length=255, blank=True, verbose_name="Адрес доставки")

    # ВАЖНО: Если ты НЕ реализовала подтверждение email, поставь default=True
    # Если реализовала — оставь default=False и добавь логику активации
    is_active = models.BooleanField(
        default=True,  # <-- Изменено с False на True для простоты (если не требуется подтверждение)
        verbose_name="Активный аккаунт"
    )
    is_staff = models.BooleanField(
        default=False,
        verbose_name="Статус персонала"
    )
    # Дата регистрации (полезное поле, часто требуется)
    date_joined = models.DateTimeField(auto_now_add=True, verbose_name="Дата регистрации")

    # Указывает Django, какой менеджер использовать для этой модели
    objects = CustomUserManager()

    # Указывает, что поле email будет использоваться как уникальный идентификатор для входа
    USERNAME_FIELD = 'email'
    # Поля, которые будут запрашиваться при создании суперпользователя через manage.py createsuperuser
    # USERNAME_FIELD не нужно добавлять сюда
    REQUIRED_FIELDS = ['phone_number']  # <-- Пример: добавили номер телефона как обязательное

    def __str__(self):
        """Возвращает строковое представление пользователя."""
        return self.email

    def get_full_name(self):
        """
        Возвращает полное имя пользователя.
        Для кастомной модели пользователя этот метод часто требуется.
        """
        # В данном случае в модели нет поля first_name/last_name, поэтому возвращаем email
        # Можно модифицировать, если добавишь эти поля
        return self.email

    def get_short_name(self):
        """
        Возвращает короткое имя пользователя.
        """
        # Аналогично get_full_name
        return self.email

    class Meta:
        verbose_name = "Пользователь"
        verbose_name_plural = "Пользователи"



