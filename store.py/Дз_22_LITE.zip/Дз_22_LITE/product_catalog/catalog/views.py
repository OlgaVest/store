# catalog/views.py

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Q, Sum, Count, Avg, Min, Max
from django.core.paginator import Paginator
from .models import Product, Category
from .forms import ProductForm


def product_list_view(request):
    products_list = Product.objects.select_related('category').all()

    # Фильтрация
    category_id = request.GET.get('category')
    if category_id:
        try:
            category_id = int(category_id)
            products_list = products_list.filter(category__id=category_id)
        except ValueError:
            pass

    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    if min_price:
        try:
            min_price = float(min_price)
            products_list = products_list.filter(price__gte=min_price)
        except ValueError:
            pass
    if max_price:
        try:
            max_price = float(max_price)
            products_list = products_list.filter(price__lte=max_price)
        except ValueError:
            pass

    # Поиск
    query = request.GET.get('q')
    if query:
        products_list = products_list.filter(
            Q(name__icontains=query) | Q(description__icontains=query)
        )

    # Сортировка
    sort_by = request.GET.get('sort', '-created_at')
    allowed_sort_params = {
        'price_asc': 'price',
        'price_desc': '-price',
        'date_asc': 'created_at',
        'date_desc': '-created_at'
    }
    if sort_by in allowed_sort_params:
        products_list = products_list.order_by(allowed_sort_params[sort_by])

    # Пагинация
    paginator = Paginator(products_list, 10)
    page_number = request.GET.get('page')
    products = paginator.get_page(page_number)

    categories = Category.objects.all()

    context = {
        'products': products,
        'categories': categories,
        'current_filters': {
            'category': category_id,
            'min_price': min_price,
            'max_price': max_price,
            'sort': sort_by,
            'q': query,
        }
    }
    return render(request, 'catalog/product_list.html', context)


def product_create_view(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)  # +FILES
        if form.is_valid():
            form.save()
            messages.success(request, 'Товар успешно создан.')
            return redirect('catalog:product_list')  # Без namespace
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = ProductForm()
    return render(request, 'catalog/product_form.html', {'form': form, 'action': 'Создать'})


def product_update_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)  # +FILES
        if form.is_valid():
            form.save()
            messages.success(request, 'Товар успешно обновлён.')
            return redirect('catalog:product_list')  # Без namespace
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = ProductForm(instance=product)
    return render(request, 'catalog/product_form.html', {'form': form, 'action': 'Редактировать', 'product': product})


def product_delete_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product_name = product.name
        product.delete()
        messages.success(request, f'Товар "{product_name}" успешно удалён.')
        return redirect('catalog:product_list')
    return render(request, 'catalog/product_confirm_delete.html', {'product': product})


def analytics_view(request):
    total_products = Product.objects.count()
    total_value = Product.objects.aggregate(Sum('price'))['price__sum'] or 0

    # Убедись, что в модели Product ForeignKey к Category имеет related_name='products'
    category_stats = Category.objects.annotate(
        product_count=Count('products'),
        total_value=Sum('products__price'),
        avg_price=Avg('products__price'),
        min_price=Min('products__price'),
        max_price=Max('products__price')
    ).filter(product_count__gt=0)

    overall_stats = Product.objects.aggregate(
        overall_avg_price=Avg('price'),
        overall_min_price=Min('price'),
        overall_max_price=Max('price')
    )

    context = {
        'total_products': total_products,
        'total_value': total_value,
        'category_stats': category_stats,
        'overall_stats': overall_stats,
    }
    return render(request, 'catalog/analytics.html', context)