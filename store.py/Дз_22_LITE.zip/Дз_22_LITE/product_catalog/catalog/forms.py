# catalog/forms.py

from django import forms
from .models import Product, Category


class ProductForm(forms.ModelForm):
    """
    Форма для создания и редактирования товара.
    Наследуется от ModelForm, связан с моделью Product.
    """

    class Meta:
        model = Product
        # Указываем поля, которые должны быть в форме.
        # '__all__' можно использовать, но лучше явно перечислить
        # для лучшего контроля и безопасности.
        fields = ['name', 'price', 'description', 'category', 'image']

        # widgets позволяют задать специфичный вид для полей формы
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите название товара'
            }),
            'image': forms.FileInput(attrs={
                'class': 'form-control'
            }),  # <-- Добавлен виджет для image
            'price': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Введите цену',
                'step': '0.01',  # Шаг для десятичных чисел
                'min': '0.01'  # Минимальное значение из валидатора модели
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Введите описание товара',
                'rows': 4  # Высота текстового поля
            }),
            'category': forms.Select(attrs={
                'class': 'form-control'
            }),
        }

    def clean_price(self):
        """
        Кастомная валидация для поля price.
        Хотя валидатор уже есть в модели, здесь можно добавить
        дополнительную логику или изменить сообщение об ошибке.
        """
        price = self.cleaned_data.get('price')
        # Валидатор MinValueValidator(0.01) из модели уже сработает,
        # но можно добавить проверку, например, на максимальную цену.
        # if price and price > 1000000:
        #     raise forms.ValidationError("Цена не может быть выше 1 000 000.")
        return price
