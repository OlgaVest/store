# catalog/urls.py

from django.urls import path
from . import views

# Пространство имён приложения. Полезно, если в проекте несколько приложений
# с одинаковыми именами маршрутов.
app_name = 'catalog'

urlpatterns = [
    # Список товаров (главная страница приложения)
    path('', views.product_list_view, name='product_list'),

    # Создание товара
    path('create/', views.product_create_view, name='product_create'),

    # Редактирование товара
    path('<int:pk>/update/', views.product_update_view, name='product_update'),

    # Удаление товара
    path('<int:pk>/delete/', views.product_delete_view, name='product_delete'),

    # Аналитика
    path('analytics/', views.analytics_view, name='analytics'),  # <-- Новый маршрут
]