# shop/admin.py

from django.contrib import admin
from .models import Category, Product

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    """
    Настройка отображения модели Category в админке.
    """
    list_display = ('name', 'description')  # Исправлено: name, description
    search_fields = ('name',)               # Исправлено: name
    ordering = ('name',)

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'price', 'order_count', 'date_added') # Добавлено: order_count
    list_filter = ('category', 'date_added')
    search_fields = ('name', 'description')
    ordering = ('-date_added',)
    list_editable = ('price', 'order_count') # Добавлено: order_count

