# shop/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.product_list_view, name='product_list'),
    path('ajax/product-list/', views.product_list_ajax_view, name='product_list_ajax'),
]
