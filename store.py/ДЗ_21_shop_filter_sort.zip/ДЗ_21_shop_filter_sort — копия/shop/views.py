# shop/views.py

from django.shortcuts import render
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from .models import Product, Category

def product_list_view(request):
    """
    Представление для отображения списка товаров с фильтрацией, сортировкой и пагинацией.
    """
    # Получаем QuerySet всех товаров
    products_list = Product.objects.all()

    # --- Фильтрация ---
    # 1. Фильтр по категории
    category_id = request.GET.get('category')
    if category_id:
        products_list = products_list.filter(category__id=category_id)

    # 2. Фильтр по диапазону цен
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    if min_price:
        try:
            min_price = float(min_price)
            products_list = products_list.filter(price__gte=min_price)
        except ValueError:
            pass # Игнорируем некорректный ввод
    if max_price:
        try:
            max_price = float(max_price)
            products_list = products_list.filter(price__lte=max_price)
        except ValueError:
            pass # Игнорируем некорректный ввод

    # 3. Фильтр по дате добавления (например, за последние N дней)
    days = request.GET.get('days')
    if days:
        try:
            days = int(days)
            from django.utils import timezone
            from datetime import timedelta
            start_date = timezone.now() - timedelta(days=days)
            products_list = products_list.filter(date_added__gte=start_date)
        except (ValueError, TypeError):
            pass # Игнорируем некорректный ввод

    # --- Сортировка ---
    sort_by = request.GET.get('sort', '-date_added') # По умолчанию - новые первые
    allowed_sort_params = {
        'price_asc': 'price',
        'price_desc': '-price',
        'popularity': '-order_count',
        'date_asc': 'date_added',
        'date_desc': '-date_added'
    }
    if sort_by in allowed_sort_params:
        products_list = products_list.order_by(allowed_sort_params[sort_by])
    else:
        # Если параметр сортировки некорректный, сортируем по умолчанию
        products_list = products_list.order_by('-date_added')

    # --- Подготовка вспомогательных данных для шаблона ---
    # Получаем список всех категорий для фильтра в шаблоне
    categories = Category.objects.all()

    # --- Пагинация ---
    paginator = Paginator(products_list, 10) # 10 товаров на странице
    page_number = request.GET.get('page')
    try:
        products = paginator.get_page(page_number)
    except PageNotAnInteger:
        # Если page_number не целое число, показываем первую страницу
        products = paginator.get_page(1)
    except EmptyPage:
        # Если страница вне диапазона (например, 9999), показываем последнюю
        products = paginator.get_page(paginator.num_pages)

    # --- Подготовка контекста ---
    context = {
        'products': products, # Передаем страницу с товарами от пагинатора
        'categories': categories,
        'current_filters': {
            'category': category_id,
            'min_price': min_price,
            'max_price': max_price,
            'days': days,
            'sort': sort_by, # Передаем текущий параметр сортировки
        }
    }

    # --- Возврат ответа ---
    return render(request, 'shop/product_list.html', context)

# shop/views.py

from django.http import JsonResponse
from django.template.loader import render_to_string
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def product_list_ajax_view(request):
    """
    Представление для обработки AJAX-запросов на получение отфильтрованного/отсортированного списка товаров.
    Возвращает HTML-фрагмент списка товаров.
    """
    # --- Логика фильтрации и сортировки (та же, что и в product_list_view) ---
    products_list = Product.objects.all()

    # Фильтрация
    category_id = request.GET.get('category')
    if category_id:
        products_list = products_list.filter(category__id=category_id)

    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    if min_price:
        try:
            min_price = float(min_price)
            products_list = products_list.filter(price__gte=min_price)
        except ValueError:
            pass
    if max_price:
        try:
            max_price = float(max_price)
            products_list = products_list.filter(price__lte=max_price)
        except ValueError:
            pass

    days = request.GET.get('days')
    if days:
        try:
            days = int(days)
            from django.utils import timezone
            from datetime import timedelta
            start_date = timezone.now() - timedelta(days=days)
            products_list = products_list.filter(date_added__gte=start_date)
        except (ValueError, TypeError):
            pass

    # Сортировка
    sort_by = request.GET.get('sort', '-date_added')
    allowed_sort_params = {
        'price_asc': 'price',
        'price_desc': '-price',
        'popularity': '-order_count',
        'date_asc': 'date_added',
        'date_desc': '-date_added'
    }
    if sort_by in allowed_sort_params:
        products_list = products_list.order_by(allowed_sort_params[sort_by])
    else:
        products_list = products_list.order_by('-date_added')

    # Пагинация (для AJAX запросов обычно показываем первую страницу,
    # но можно передавать номер страницы и через GET-параметр)
    # Для простоты будем возвращать первую страницу отфильтрованного списка.
    # В более сложных случаях можно добавить пагинацию и для AJAX.
    paginator = Paginator(products_list, 10)
    page_number = request.GET.get('page', 1) # По умолчанию первая страница
    try:
        products = paginator.get_page(page_number)
    except PageNotAnInteger:
        products = paginator.get_page(1)
    except EmptyPage:
        products = paginator.get_page(paginator.num_pages)

    # --- Рендеринг HTML-фрагмента ---
    # Рендерим только часть шаблона, которая отвечает за отображение товаров
    # Создадим новый шаблон для этого фрагмента или используем существующий,
    # но обернем список в блок, который будем заменять.
    html_fragment = render_to_string(
        'shop/partials/product_list_fragment.html', # Новый шаблон
        {'products': products},
        request=request
    )

    # Возвращаем JSON-ответ с HTML-фрагментом
    return JsonResponse({'html_fragment': html_fragment})

